def test_func():
#    from brain_games import cli
    from brain_games.games import qqq_source
#    cli.welcome_user()
    qqq_source.for_qqq()

