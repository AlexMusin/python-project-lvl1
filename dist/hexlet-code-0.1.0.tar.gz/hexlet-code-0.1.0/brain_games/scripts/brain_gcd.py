"""GCD game launch."""

from brain_games import game_logic


def main():
    """Play gcd game."""
    game_name = 'gcd'
    game_logic.logic(game_name)
