def for_qqq():
    print('Its alive!')

