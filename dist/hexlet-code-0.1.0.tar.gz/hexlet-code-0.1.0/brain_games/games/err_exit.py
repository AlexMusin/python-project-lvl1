"""Error and exit module"""
import sys


def error():
    """Say error."""
    incorrect = 'Incorrect!\nPlease run the game again'
    sys.exit(incorrect)


if __name__ == '__main__':
    error()
