"""Odd-or-even game module"""

import random
import prompt
from brain_games.games import err_exit

rules = 'Answer "yes" if the number is even, otherwise answer "no".'
right_limit = -256
left_limit = 255


def even():
    """Determine 'even' game variables"""
    number = random.randint(right_limit, left_limit)
    condition = number % 2 == 1
    print('Question: {0}'.format(number))
    answer = prompt.string('Your answer: ')
    if answer == 'yes':
        answer = 0
    elif answer == 'no':
        answer = 1
    else:
        err_exit.error()
    return(condition, answer)


if __name__ == '__main__':
    even()