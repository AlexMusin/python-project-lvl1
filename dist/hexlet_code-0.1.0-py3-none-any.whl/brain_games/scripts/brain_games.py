#!/usr/bin/env python

def say_welcome():
    return ('Welcome to the Brain Games!')


def main():
    print(say_welcome())

    
if __name__ == '__main__':
    main()